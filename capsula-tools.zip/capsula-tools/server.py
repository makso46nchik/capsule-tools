#!/usr/bin/env python3
"""Authenticated, allow-listed local control panel for Capsule Tools."""
import json, os, subprocess, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
ROOT = Path("/opt/capsula-tools")
TOKEN_FILE = Path("/etc/capsula-tools/token")
PORT = int(os.environ.get("CAPSULA_TOOLS_PORT", "8787"))
WWW = ROOT / "www"

def run(args, timeout=3):
    try:
        p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=timeout, check=False)
        return p.stdout.strip()
    except Exception:
        return ""

def service_status():
    rows=[]
    for name in ("avahi-daemon","nqptp","shairport-sync"):
        s=run(["rc-service",name,"status"]) if os.path.exists("/sbin/rc-service") else ""
        rows.append(f"{name}: {s or 'служба не найдена / статус недоступен'}")
    return "\n".join(rows)

def status():
    mem=run(["sh","-c","awk '/MemTotal/ {t=$2} /MemAvailable/ {a=$2} END {if(t) printf \"%.0f MiB всего, %.0f MiB доступно\",t/1024,a/1024; else print \"недоступно\"}' /proc/meminfo"])
    disk=run(["df","-h","/"])
    disk="; ".join(disk.splitlines()[-1].split()) if disk else "недоступно"
    uptime=run(["sh","-c","cat /proc/uptime | cut -d' ' -f1"])
    try:
        secs=int(float(uptime)); uptime=f"{secs//86400} дн. {(secs%86400)//3600} ч. {(secs%3600)//60} мин."
    except Exception: uptime="недоступно"
    temp="недоступно"
    for p in Path("/sys/class/thermal").glob("thermal_zone*/temp"):
        try:
            raw=int(p.read_text().strip()); temp=f"{raw/1000:.1f} °C" if raw>1000 else f"{raw} °C"; break
        except Exception: pass
    arch=run(["uname","-m"]) or "?"
    osver=Path("/etc/alpine-release").read_text().strip() if Path("/etc/alpine-release").exists() else run(["uname","-sr"])
    net=run(["ip","-brief","addr"]) or run(["ifconfig"]) or "недоступно"
    wifi=run(["iwgetid","-r"]) if (os.path.exists("/usr/sbin/iwgetid") or os.path.exists("/usr/bin/iwgetid")) else ""
    if wifi:
        net="Wi-Fi SSID: "+wifi+"\\n"+net
    vol=None
    if os.path.exists("/usr/bin/amixer") or os.path.exists("/usr/sbin/amixer"):
        out=run(["amixer","get","Master"])
        import re
        m=re.findall(r"\[(\d{1,3})%\]",out)
        if m:
            try: vol=max(0,min(100,int(m[-1])))
            except ValueError: pass
    return {"uptime":uptime,"memory":mem or "недоступно","disk":disk,
            "temperature":temp,"arch":arch,"os":osver,"network":net,
            "services":service_status(),"volume":vol}

class Handler(BaseHTTPRequestHandler):
    server_version = "CapsuleTools/0.1"
    def log_message(self, fmt, *args):
        # Do not log auth headers or request bodies.
        print("%s - %s" % (self.client_address[0], fmt % args))
    def send(self, code, payload, content_type="application/json; charset=utf-8"):
        body=payload if isinstance(payload,bytes) else json.dumps(payload,ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type",content_type)
        self.send_header("Content-Length",str(len(body))); self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path in ("/","/index.html"):
            try: self.send(200,(WWW/"index.html").read_bytes(),"text/html; charset=utf-8")
            except Exception: self.send(500,{"error":"Панель не найдена"})
            return
        if self.path!="/api/status": self.send(404,{"error":"Не найдено"}); return
        if not self.auth(): self.send(401,{"error":"Неверный токен доступа"}); return
        self.send(200,status())
    def do_POST(self):
        if not self.auth(): self.send(401,{"error":"Неверный токен доступа"}); return
        try:
            n=int(self.headers.get("Content-Length","0"))
            if n>4096: self.send(413,{"error":"Слишком большой запрос"}); return
            data=json.loads(self.rfile.read(n) or b"{}")
        except Exception: self.send(400,{"error":"Некорректный JSON"}); return
        if self.path=="/api/volume":
            try: v=int(data.get("volume",-1))
            except Exception: v=-1
            if not 0<=v<=100: self.send(400,{"error":"Громкость должна быть от 0 до 100"}); return
            if not (os.path.exists("/usr/bin/amixer") or os.path.exists("/usr/sbin/amixer")):
                self.send(501,{"error":"amixer не установлен. Системный микшер не изменён."}); return
            out=run(["amixer","set","Master",f"{v}%"])
            if not out or "Unable to find" in out or "Invalid" in out:
                self.send(501,{"error":"ALSA-контроллер Master не найден. Проверьте amixer controls."}); return
            self.send(200,{"volume":v,"message":"Команда отправлена ALSA mixer."}); return
        if self.path=="/api/reboot":
            if data.get("confirm") is not True: self.send(400,{"error":"Требуется подтверждение"}); return
            self.send(200,{"message":"Команда перезагрузки отправлена."})
            # Short delay lets HTTP response flush; fixed command, never user-supplied.
            subprocess.Popen(["/bin/sh","-c","sleep 1; /sbin/reboot"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        self.send(404,{"error":"Не найдено"})
    def auth(self):
        try: expected=TOKEN_FILE.read_text().strip()
        except Exception: return False
        supplied=self.headers.get("X-Capsule-Token","")
        return bool(expected) and len(supplied)==len(expected) and __import__("hmac").compare_digest(supplied,expected)

if __name__=="__main__":
    if not TOKEN_FILE.exists():
        raise SystemExit("Missing token. Run install.sh first.")
    ThreadingHTTPServer(("0.0.0.0",PORT),Handler).serve_forever()

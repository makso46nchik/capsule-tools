#!/bin/sh
set -eu
[ "$(id -u)" -eq 0 ] || { echo "Запусти от root: sh uninstall.sh" >&2; exit 1; }
if command -v rc-service >/dev/null 2>&1; then rc-service capsula-tools stop >/dev/null 2>&1 || true; fi
if command -v rc-update >/dev/null 2>&1; then rc-update del capsula-tools default >/dev/null 2>&1 || true; fi
rm -f /etc/init.d/capsula-tools /opt/capsula-tools/server.py
rm -rf /opt/capsula-tools/www
rmdir /opt/capsula-tools 2>/dev/null || true
rm -f /etc/capsula-tools/token
rmdir /etc/capsula-tools 2>/dev/null || true
echo "Capsule Tools удалена. Python и другие системные пакеты/службы не удалялись."
